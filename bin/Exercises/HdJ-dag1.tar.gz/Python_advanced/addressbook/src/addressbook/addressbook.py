#!/usr/bin/env python3
# "object" is een caompatibility dingetje met Python  2
class Addressbook(object):
	"""
	An address object.
	"""
	def __add__(self, added):
		pass

		
	def __init__(self, name="My Addressbook"): 
		self.name = name
		self._contacts = []
	
	def add_contact(self, contact):
		self._contacts.add(contact)
	
	def __len__(self):
		return len(self._contacts)
	
	def __repr__(self):
		return '<class Addressbook \"%s\", containing %d contacts'%(
			self.name, len(self)
		)
	
class Contact(object):
	"""
	A Contact object.
	New: class atttributes!
	"""
	_allowed_attributes ={}

	def __init__(self, fname, sname):
		self.fname=fname
		self.sname=sname

	def __add__(self, other):
		"""
		Actually we are going to define this as a merge: return a 
		new Contact with all the properties of the old one, AND new ones from
		the "other" object.
		"""
		new = Contact(self.fname,self.sname)
		for att in  other.get_attrs() | self.get_attrs()  :
			if hasattr(self,att) :
				new.add_attr(att, getattr(self,att))
			else: 
				new.add_attr(att,getattr(other,att))
		return new

	def add_attr(self,attr_name,attr_val):
		#if attr_name in self._allowed_attributes:
		setattr(self,attr_name, attr_val)

	def get_attrs( self):
		myattrs= set()
		for a in dir(self):
			"""
			"""
			if a.startswith('_'):
				continue
			if callable(getattr(self, a)):
				continue
			else:
				myattrs.add(a)		
		return myattrs
	
